 #include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<fcntl.h>
 #include<unistd.h>
 #include<assert.h>
 #include <sys/wait.h>

  char *argv[20];
  char sp=' ';
  int argc,s;
  void mygen()
 {
                if (*argv[0] == '\0') return;
                if (fork() == 0){
 			execlp(argv[0],argv[0],NULL);
 		}
                 printf("%s\n",argv[1]);
 		 if (*argv[1] != '&') { printf("waiting\n");wait(&s);wait(&s);}
 }
 
 void cmdpipe()
 {
 		int pipe_fd[2]; 
 		pid_t pid1,pid2;
 		pipe(pipe_fd);
   printf("in pipe\n");
 		if ((pid1=fork()) == 0){
 				close(1);
 				dup(pipe_fd[1]);
 				execlp(argv[0],argv[0],NULL);
 		}else
 		{		
 				close(pipe_fd[1]);
 				if  ((pid2=fork())==0){
 						close(0);
 						dup(pipe_fd[0]);
 						execlp(argv[2],argv[2],NULL);
 				}
 		} 
 		wait(&s);wait(&s);
 }
 
  void readcmd()
  {
 		int i = 0;
 		char  cmd[20],temp[20];
 		char *potoarr;
 		int j = 0;
                argv[1]=&sp;
 		potoarr = cmd;
 		printf("aji@ice-desktop$ ");
 		fgets(cmd,sizeof(cmd),stdin);				
 		while(*potoarr != '\0'){
 			if (*potoarr != ' ' && *potoarr != '\n' ){
 				temp[i++] = *potoarr++;
 			}else{
 				potoarr++;			
 				temp[i] = '\0';
 				argv[j++] =  strdup(temp);
 				i = 0;		
 			}
 		}
 		argc = j;
 }

void callfunction(void)
 {
       if (argc < 3)
		mygen();
	else if (argc == 3){
		 if (*argv[1] == '|')
			cmdpipe();
	}	
}

int main()
{
		while(1){
			readcmd();
			callfunction();
		}
}
