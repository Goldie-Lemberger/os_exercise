#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

enum {
    MaxLigne = 1024,
    MaxMot = MaxLigne / 2,
    MaxDirs = 100,
    MaxPathLength = 512,
};
void decouper(char *, char *, char **, int);
void affiche_prompt(void);
int in_array(char *, char **);
void executer_PATH(char **);
void usage(char *);

int
main(void)
{
    char ligne[MaxLigne];
    char * mot[MaxMot];
    char * mot2[MaxMot];
    int fd[2];
    int pipe_flag, i;
    pid_t tmp;

    for(affiche_prompt();fgets(ligne, sizeof ligne, stdin) != 0;affiche_prompt()) {
        decouper(ligne, " \t\n", mot, MaxMot);

        if (mot[0] == 0)
            continue;

        /* Is there a pipe? */
        pipe_flag = in_array("|", mot);
        if (pipe_flag > 0){
            if (pipe(fd) != 0)
               usage("Problème dans la création du pipe");

            if(mot[pipe_flag] == 0) {
                fprintf(stderr,
                    "Vous devez entrer une commande après le pipe (|)\n");
            }
            //Copy second instruction in an array
            i = 0;
            while(pipe_flag <= MaxMot) {
                mot2[i] = mot[pipe_flag];
                pipe_flag++;
                i++;
            }
        }

        tmp = fork();

        if (tmp < 0){
            perror("fork");
            continue;
        }

        if (tmp != 0)
        {
            if (pipe_flag > 0){ //ther is a pipe
                pid_t pid2 = fork(); //for the shell not to be closed after a pipe

                if (pid2 < 0){
                    perror("fork");
                }
                else if (pid2 != 0){
                  close(fd[0]);
                  close(fd[1]);
                  int corpse;
                  int status;
                  while ((corpse = wait(&status)) != pid2 && corpse != -1)
                    fprintf(stderr, "Got-1: PID %d exit status 0x%.4X\n", corpse, status);
                  fprintf(stderr, "End-1: PID %d exit status 0x%.4X\n", corpse, status);
                }
                else
                {
                  close(fd[0]);
                  dup2(fd[1], STDOUT_FILENO);
                  close(fd[1]);
                  executer_PATH(mot);
                }
            }
            {
              int corpse;
              int status;
              /* These closes are redundant until you remove the inner wait code */
              close(fd[0]);
              close(fd[1]);
              while ((corpse = wait(&status)) != tmp && corpse != -1)
                fprintf(stderr, "Got-2: PID %d exit status 0x%.4X\n", corpse, status);
              fprintf(stderr, "End-2: PID %d exit status 0x%.4X\n", corpse, status);
            }
            continue;
        }

        if (pipe_flag == 0){ //There is no pipe
            executer_PATH(mot);
        }
        //there is one pipe
        close(fd[1]);
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]);
        executer_PATH(mot2);
    }
    printf("Bye\n");
    return 0;
}


/* decouper  --  decouper une chaine en mots */
void
decouper(char * ligne, char * separ, char * mot[], int maxmot){
  int i;

  mot[0] = strtok(ligne, separ);
  for(i = 1; mot[i - 1] != 0; i++){
    if (i == maxmot){
      usage("Erreur dans la fonction decouper: trop de mots");
      mot[i - 1] = 0;
      break;
    }
    mot[i] = strtok(NULL, separ);
  }
}

/* affiche_prompt
    affect à la variable globale PROMPT "?" + le répertoire courant*/
void
affiche_prompt(void){
    char buffer[MaxPathLength];
    if (getcwd (buffer, MaxPathLength) == NULL)
        usage("impossible de connaître le répertoire courant");
    printf("%s", strcat(buffer, "? "));
}

/* in_array --
    renvoie 0 si le mot n'est pas trouvé, la case suivante sinon */
int
in_array(char * mot_cherche, char ** mot)
{
    int i;
    for(i = 1; i <= MaxMot; i++){
        if (mot[i] == 0)
            break;

        if (strcmp(mot[i], mot_cherche) == 0){
            mot[i] = 0;
            return i+1;
        }
    }
    return 0;
}

/* executer_PATH -- essaye de lancer la commande donnée en argument avec les
chemins enregistrés dans PATH */
void
executer_PATH(char ** commande){
    int i;
    char * dirs[MaxDirs];
    char pathname[MaxPathLength];
    fprintf(stderr, "Child %d: %s\n", (int)getpid(), commande[0]);

    /* Decouper PATH en repertoires */
    decouper(strdup(getenv("PATH")), ":", dirs, MaxDirs);

    for(i = 0; dirs[i] != 0; i++){
        snprintf(pathname, sizeof pathname, "%s/%s", dirs[i], commande[0]);
        execv(pathname, commande);
    }
    /* Aucun exec n’a fonctionné */
    fprintf(stderr, "%s: not found\n", commande[0]);
    exit(1);
}

/* usage -- afficher un message d'erreur et sortir */
void
usage(char * message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}
